#' Annotate Illumina expression array probes
#'
#'
#' @description
#' \code{probe.annotate} This function get the annotations from the \code{\link{illuminaHumanv4.db}},
#' \code{\link{org.Hs.eg.db}}, and \code{\link{TxDb.Hsapiens.UCSC.hg19.knownGene}} packages
#' and is used in the \code{expr.annotate} function to merge pvalue results with probe locations
#' and gene names note, that you are merging your expression regression reuslts with the
#' annotation based on NuID
#'
#' @return list of size 1
#' \describe{
#' \item{DT.probes.annotated}{\code{data.table} object of probe annoatations
#' with \code{data.table} key NuID}
#' }
#'
#' @examples
#' \dontrun{
#' probe.annotate()
#' }
#'
#' @import data.table
#' @importMethodsFrom GenomicRanges as.data.frame
#' @importMethodsFrom AnnotationDbi as.list select
#' @export


probe.annotate <- function(){

  # first get annotation information of probes
  DT.loc <- as.data.table(illuminaHumanv4.db::illuminaHumanv4fullReannotation())
  #DT.loc[!is.na(GenomicLocation)]
  setkey(DT.loc,IlluminaID)

  # there are multiple locations because BLAST cant find a consensus solution
  # so in the following code we take the first GenomicLocation and remove the
  # rest
  DT.loc[, paste0("a",1:4):=tstrsplit(GenomicLocation, " ", fixed=TRUE)][]
  DT.loc[, paste0("a",2:4):=NULL]
  DT.loc[, paste0("b",1:6):=tstrsplit(a1, ",", fixed=TRUE)][]
  DT.loc[, paste0("b",2:6):=NULL]
  DT.loc[, c("chr","start","end","strand"):=tstrsplit(b1, ":", fixed=TRUE)][]
  DT.loc[,c("start","end"):=list(as.numeric(start), as.numeric(end))]
  DT.loc <- DT.loc[!is.na(NuID)][!is.na(start)][!is.na(end)]
  #str(DT.loc)
  setnames(DT.loc, c("start","end","EntrezReannotated"), c("probe.start","probe.end","ENTREZID"))
  setkey(DT.loc,NULL)
  setkey(DT.loc,ENTREZID)

  # now get annotation information of genes
  x <- org.Hs.eg.db::org.Hs.egSYMBOL2EG
  mapped_probes <- mappedkeys(x)
  xx <- as.list(x[mapped_probes])
  entrezID <- unlist(xx)

  DT.gene = as.data.table(select(TxDb.Hsapiens.UCSC.hg19.knownGene::TxDb.Hsapiens.UCSC.hg19.knownGene, entrezID, "GENEID",
                                 columns=c("GENEID", "TXCHROM", "TXSTART", "TXEND","TXSTRAND")))
  setnames(DT.gene, "GENEID", "ENTREZID")
  DT.gene <- DT.gene[complete.cases(DT.gene)]
  setkey(DT.gene, ENTREZID)
  DT.gene <- unique(DT.gene)
  DT.gene.temp <- as.data.table(select(org.Hs.eg.db::org.Hs.eg.db, DT.gene$ENTREZID, c("SYMBOL", "GENENAME")));DT.gene.temp
  setkey(DT.gene.temp, ENTREZID)
  DT.gene <- DT.gene[DT.gene.temp]

  # merge probe info with gene info
  DT.probes.annotated <- DT.gene[DT.loc[,.(IlluminaID,ArrayAddress,NuID,ProbeQuality,CodingZone,ProbeSequence,
                    ENTREZID,SymbolReannotated,EnsemblReannotated,chr,
                    probe.start, probe.end, strand)]]
  DT.probes.annotated[,ENTREZID:=as.numeric(ENTREZID)]
  setkey(DT.probes.annotated,NULL)
  setkey(DT.probes.annotated,NuID)

  return(DT.probes.annotated)

}



