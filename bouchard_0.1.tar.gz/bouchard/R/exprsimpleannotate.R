#' Annotate Expression probes
#'
#' @param DT data.table consisting of NuID and a summary measure:
#' \enumerate{
#'  \item NuID
#'  \item pvalue or effect size or cannonical weight or anything quantitative
#' }
#' the column names can be anything but the first column must correspond to the probe name
#' and the second column is the quantitative measure. The key must be set to the probename
#' using \code{\link{setkey}}
#'
#' @param GR annotation data.table of probes from \code{\link{probe.annotate}}
#'
#' @description
#' \code{expr.simple.annotate} function takes expression probe names and some quantitative measure
#' as input, and adds annotation information. This quantitative measure can be anything
#'
#' @return data.table of
#' \describe{
#' \item{probe name}{data.table of results (with gene annotation, base position,
#' chromosome location, p and q values)}
#' \item{chromosome}{character vector of significant probes based on p values}
#' \item{base pair position}{character vector of significant probes based on q values}
#' \item{quantitative variable}{GRanges object based on significant p values}
#' \item{other annotation information}{not needed here}
#' }
#'
#' @examples
#' \dontrun{
#' GR.probe <- probe.annotate()
#' expr.simple.annotate(DT, GR=GR.probe)
#' }
#'
#' @import data.table
#' @export


expr.simple.annotate <- function(DT, GR){

  # Merge all tables
  DT <- GR[DT]
  set(DT, i=NULL, j="CHR.num", value=sub("chr","", DT[["chr"]]))

  DT[CHR.num=="X",CHR.num:=23]
  DT[CHR.num=="Y",CHR.num:=24]
  DT[,CHR.num:=as.numeric(CHR.num)]

  return(DT)

}



