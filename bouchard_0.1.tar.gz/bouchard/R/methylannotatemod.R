#' Analyse DNA Methylation Regression Results restricted to raw mean methylation values
#'
#' @param file filename with full path of where the results from betareg are stored. must have five
#' columns in the following order and cannot have a header row:
#' \enumerate{
#'  \item probe name
#'  \item pvalue
#'  \item z score
#'  \item standard error
#'  \item effect size
#' }
#' @param thresholdp threshold of what is considered significant based on p-value
#' @param thresholdq threshold of what is considered significant based on q-value
#' @param lowermeth all probes with mean methylation values less than \code{lowermeth}
#' are excluded from results, plots and FDR calculations
#' @param uppermeth all probes with mean methylation values greater than \code{uppermeth}
#' are excluded from results, plots and FDR calculations
#' @param tissue character name of tissue "cord" or "placenta"
#'
#' @description
#' \code{methyl.annotate.mod} function takes beta regression results as input, and adds
#' annotation information. This function is similar to \code{\link{methyl.annotate}}, however
#' it removes probes with mean methylation values above and below a user defined threshold
#' @note You need to calculate mean and sd methylation for each probe before using this function
#'
#' @return list of size 5
#' \describe{
#' \item{DT}{data.table of results (with gene annotation, base position, chromosome location, p and q values)}
#' \item{significantp}{character vector of significant probes based on p values}
#' \item{significantq}{character vector of significant probes based on q values}
#' \item{sigpGranges}{GRanges object based on significant p values}
#' \item{sigqGranges}{GRanges object based on significant q values}
#' }
#'
#' @examples
#' \dontrun{
#' library(FDb.InfiniumMethylation.hg19)
#' hm450 = FDb.InfiniumMethylation.hg19::get450k()
#' setwd("~/share/greenwood.group/PROJECTS/Luigi_Bouchard/Methylation/
#' 10-06-2014/bloodcord/FILTERED_DATA")
#' load("matrix_filter1.RData")
#' DT.raw.cord <- as.data.table(filtered_matrix, keep.rownames = TRUE)
#' setkey(DT.raw.cord,rn)
#' setwd("~/share/greenwood.group/PROJECTS/Luigi_Bouchard/Methylation/
#' 10-06-2014/placenta/FILTERED_DATA")
#' load("matrix_filter1.RData")
#' DT.raw.placenta <- as.data.table(filtered_matrix, keep.rownames = TRUE)
#' setkey(DT.raw.placenta,rn)
#' DT.raw.cord[, "mean_methylation":=rowMeans(DT.raw.cord[,-1,with=FALSE])]
#' DT.raw.placenta[, "mean_methylation":=rowMeans(DT.raw.placenta[,-1,with=FALSE])]
#' DT.raw.cord[, "sd_methylation":=rowSds(DT.raw.cord[,c(-1,-47),with=FALSE])]
#' DT.raw.placenta[, "sd_methylation":=rowSds(DT.raw.placenta[,c(-1,-50),with=FALSE])]
#' methyl.annotate.mod("DT.cord.noage",thresholdp=1e-3, thresholdq=1e-1,
#' lowermeth=0.10, uppermeth=0.90, tissue="Cordblood")
#' }
#'
#' @import data.table
#' @export


methyl.annotate.mod <- function(file, thresholdp=1e-3, thresholdq=1e-1,lowermeth=0.10, uppermeth=0.90, tissue){

  DT <- fread(file)
  setnames(DT, c("V1","V2","V3","V4","V5"), c("probe","pvalue","z","sd","effect"))

  # use this to get CHR and BP, then merge with betareg results
  probe.info <- hm450[DT[["probe"]]]
  f <- data.table::data.table(probe=names(probe.info),CHR=as.data.frame(probe.info@seqnames)$value,
                              BP=as.numeric(probe.info@elementMetadata$probeStart))
  data.table::setkey(f,probe)

  # get nearest Transcription start sites
  TSS <- data.table::data.table(FDb.InfiniumMethylation.hg19::getNearestTSS(probe.info), keep.rownames=TRUE)
  data.table::setkey(TSS,rn)

  # change names to merge in with DT
  data.table::setnames(TSS, c("queryHits","subjectHits","distance","nearestGeneSymbol","nearestTranscript"),
                       c("TSSqueryHits","TSSsubjectHits","TSSdistance","TSSnearestGeneSymbol","TSSnearestTranscript"))

  # get nearest genes
  Transcript <- data.table::data.table(FDb.InfiniumMethylation.hg19::getNearestTranscript(probe.info), keep.rownames=TRUE)
  data.table::setkey(Transcript,rn)

  #     DT[,c("significant.p","lower95","upper95","tissue"):=
  #            list(pvalue<=thresholdp,effect+qnorm(0.025)*sd,effect+qnorm(0.975)*sd,tissue),]

  set(DT,i=NULL, j="significant.p", value=DT[["pvalue"]]<=thresholdp)
  set(DT,i=NULL, j="lower95", value=DT[["effect"]]+qnorm(0.025)*DT[["sd"]])
  set(DT,i=NULL, j="upper95", value=DT[["effect"]]+qnorm(0.975)*DT[["sd"]])

  setkey(DT,probe)

  # Merge all tables
  DT <- DT[f][Transcript][TSS]

  set(DT, i=NULL, j="CHR.num", value=as.numeric(sub("chr","", DT[["CHR"]])))

  # significant probes based on pvalue threshold
  probenames.p <- DT[significant.p==TRUE][,c("probe","CHR.num","BP","effect","sd","nearestGeneSymbol","distance","TSSnearestGeneSymbol","TSSdistance"),with=F]

  # GRanges object for significant hits based on p value
  probenames.p.granges <- hm450[probenames.p[["probe"]]]

  # filter for lowermethylation and uppermethylation thresholds
  DT <- if(tissue=="cord") DT.raw.cord[,c("rn","mean_methylation","sd_methylation"),with=FALSE][DT] else  DT.raw.placenta[,c("rn","mean_methylation","sd_methylation"),with=FALSE][DT]
  DT <- DT[mean_methylation>=lowermeth][mean_methylation<=uppermeth]
  setnames(DT,"rn","probe")

  # q-value
  qobj <- qvalue::qvalue(DT[["pvalue"]])
  set(DT, i=NULL, j="qvalue",value=qobj$qvalues)
  DT[,"significant.q":=qvalue<=thresholdq]

  # significant probes based on qvalue threshold
  probenames.q <- DT[significant.q==TRUE][,c("probe","CHR.num","BP","effect","sd","nearestGeneSymbol","distance","TSSnearestGeneSymbol","TSSdistance"),with=F]

  # GRanges object for significant hits based on q value
  probenames.q.granges <- hm450[probenames.q[["probe"]]]

  return(list(results=DT, significantp=probenames.p, significantq=probenames.q,
              sigpGranges=probenames.p.granges,sigqGranges=probenames.q.granges))

}
