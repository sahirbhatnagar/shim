#' Annotate DNA Methylation Probes
#'
#' @param DT data.table consisting of probe name and a summary measure:
#' \enumerate{
#'  \item probe name
#'  \item pvalue or effect size or cannonical weight or anything quantitative
#' }
#' the column names can be anything but the first column must correspond to the probe name
#' and the second column is the quantitative measure. The key must be set to the probename
#' using \code{\link{setkey}}
#'
#' @description
#' \code{cg.annotate} function takes cg probe names and some quantitative measure
#' as input, and adds annotation information. This quantitative measure can be anything
#'
#' @return data.table of
#' \describe{
#' \item{probe name}{data.table of results (with gene annotation, base position, chromosome location, p and q values)}
#' \item{chromosome}{character vector of significant probes based on p values}
#' \item{base pair position}{character vector of significant probes based on q values}
#' \item{quantitative variable}{GRanges object based on significant p values}
#' }
#'
#' @examples
#' \dontrun{
#' library(FDb.InfiniumMethylation.hg19)
#' hm450 = FDb.InfiniumMethylation.hg19::get450k()
#' cg.annotate(DT)
#' }
#'
#' @import data.table
#' @export


cg.annotate <- function(DT){

  # use this to get CHR and BP, then merge with betareg results
  probe.info <- hm450[DT[[1]]]
  f <- data.table::data.table(probe=names(probe.info),CHR=as.data.frame(probe.info@seqnames)$value,
                              BP=as.numeric(probe.info@elementMetadata$probeStart))
  data.table::setkey(f,probe)

  # get nearest genes
  Transcript <- data.table::data.table(FDb.InfiniumMethylation.hg19::getNearestTranscript(probe.info), keep.rownames=TRUE)
  data.table::setkey(Transcript,rn)

  # Merge all tables
  DT <- DT[f][Transcript]

  set(DT, i=NULL, j="CHR.num", value=as.numeric(sub("chr","", DT[["CHR"]])))

  return(DT)

}
