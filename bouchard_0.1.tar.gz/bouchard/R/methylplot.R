#' Plot DNA Methylation results
#'
#' @description
#' \code{methyl.plot} function that writes to file the manhattan, Q-Q, Volcano, histogram of p and q values plots
#'
#' @param DT annotated dataset returned from \code{\link{methyl.annotate}} function (e.g. DT.cord.bsage$results)
#' @param plot.path path of where you want the plots to be saved (must end with /)
#' @param plot.name name of plot file without path (e.g. cord_noage). This will be the name for the hist,
#' qq, manhattan and volcano plots with the prefix being hist, qq, man, volcano (e.g. hist_cord_no_age)
#' @param tissue the tissue name as character. this is used for the title of all plots e.g. "Cordblood" or "Placenta"
#' @param primary.covariate the primary covariate of interest as a character. This is used for the title of the plots
#' e.g. Manhattan plot for percentFAT pvalues
#' @param covariates the covariates that were adjusted for e.g. "controlling for gestational age". If you didnt control for anything,
#' then just put c() (default)
#' @param highlight character vector of probes names to highlight on manhattan plot
#' empty character c() is the default
#'
#' @return
#' This function writes to file the 5 plots
#' \enumerate{
#' \item Manhattan plot (using \code{\link[qqman]{manhattan}} function from
#' \href{http://cran.r-project.org/web/packages/qqman/index.html}{qqman} pacakge) with significant
#' q value probes highlighted in green (as set by user in \code{\link{methyl.annotate}} or \code{\link{methyl.annotate.mod}} )
#' \item Q-Q plot (using \code{\link[qqman]{qq}} function from \href{http://cran.r-project.org/web/packages/qqman/index.html}{qqman} pacakge)
#' \item Volcano plot (-log10p vs. effect size) with gene names of significant q value probes (as set by user in \code{\link{methyl.annotate}} )
#' \item Histogram of p values
#' \item Histogram of q values
#' }
#'
#' @examples
#' \dontrun{
#' library(FDb.InfiniumMethylation.hg19)
#' hm450 = FDb.InfiniumMethylation.hg19::get450k()
#' DT.cord.noage.annotated <- methyl.annotate("DT.cord.noage",thresholdp=1e-3, thresholdq=1e-1)
#' methyl.plot(DT.cord.noage.annotated$results, getwd(), "cord_noage", "Cordblood", "percentFAT" )
#' }
#'
#' @import data.table
#' @export



methyl.plot <- function(DT, plot.path, plot.name, tissue, primary.covariate=c() , covariates=c(), highlight=c()) {

  # significant probes based on qvalue threshold
  probenames.q <- DT[significant.q==TRUE][,c("probe","CHR.num","BP","effect","sd","nearestGeneSymbol","distance","TSSnearestGeneSymbol","TSSdistance"),with=F]

  # Manhattan plot
  png(filename=paste0(plot.path,"man_",plot.name,".png"))
  qqman::manhattan(DT, p="pvalue",snp="probe",chr="CHR.num", highlight=probenames.q[["probe"]],suggestiveline=FALSE,genomewideline=FALSE,
            main=paste("Manhattan plot for", primary.covariate, "p-values on",tissue,"\n Methylation levels,",covariates))
  dev.off()

  # Q-Q plot
  png(filename=paste0(plot.path,"qq_",plot.name,".png"))
  qqman::qq(DT[["pvalue"]], main=paste("Q-Q plot for", primary.covariate, "p-values on",tissue,"\n Methylation levels,",covariates))
  dev.off()

  # Histogram of p-values
  png(filename=paste0(plot.path,"histp_",plot.name,".png"))
  hist(DT[["pvalue"]], xlab="pvalue", main=paste("Histogram of", primary.covariate, "p-values on",tissue,"\n Methylation levels,",covariates))
  dev.off()

  # Histogram of q-values
  png(filename=paste0(plot.path,"histq_",plot.name,".png"))
  hist(DT[["qvalue"]], xlab="qvalue", main=paste("Histogram of", primary.covariate, "q-values on",tissue,"\n Methylation levels,",covariates))
  dev.off()

  #Volcano Plot
  png(filename=paste0(plot.path,"volcano_",plot.name,".png"))
  plot(DT[["effect"]], -log10(DT[["pvalue"]]), pch=20, xlab=paste("effect size of",primary.covariate,"on methylation"),
       ylab=expression(-log[10](italic(p))),
       main=paste("Volcano plot for",tissue," Methylation levels\n",covariates))
  # Add colored points: if qvalue <= thersholdq
  with(subset(DT, significant.q==TRUE ), points(effect, -log10(pvalue), pch=20, col="green3"))
  # Label points with the textxy function from the calibrate plot
  with(subset(DT, significant.q==TRUE), calibrate::textxy(effect, -log10(pvalue), labs=nearestGeneSymbol, cex=.8))
  dev.off()

}
