#' Analyse Expression Regression Results
#'
#' @param file filename with full path of where the results from betareg are stored. must have five
#' columns in the following order and cannot have a header row:
#' \enumerate{
#'  \item NuID
#'  \item ENTREZID
#'  \item pvalue
#'  \item z score
#'  \item standard error
#'  \item effect size
#' }
#' @param thresholdp threshold of what is considered significant based on p-value
#' @param thresholdq threshold of what is considered significant based on q-value
#' @param tissue character name of tissue "cord" or "placenta"
#' @param GR annotation data.table of probes from \code{\link{probe.annotate}}
#'
#' @description
#' \code{expr.annotate} function takes regression results as input, and adds
#' annotation information.
#'
#' @return list of size 4
#' \describe{
#' \item{DT}{\code{\link{data.table}} of results (with gene annotation, base position, chromosome location, p and q values)}
#' \item{sigpGranges}{GRanges object based on significant p values}
#' \item{sigqGranges}{GRanges object based on significant q values}
#' \item{allGranges}{GRanges object with all probes that dont have a missing genomic location}
#' }
#' @note Some of the probes do not have proper annotation information, as a result
#' they might not have chromosomal information. If you use the output of this function
#' as the input to \code{\link{expr.plot}} then the manhattan plot will automatically
#' remove the probes with no chromosomal information, but will still plot the probes in the
#' Q-Q, volcano, p-value dist, q-value dist, plots
#' @examples
#' \dontrun{
#'    GR.probe <- probe.annotate()
#'    file = list.files("~/share/sy/bouchard/expression/probes/results/")
#'    expr.annotate(file[1], GR=GR.probe)
#' }
#'
#' @import data.table
#' @export


expr.annotate <- function(file, thresholdp=1e-3, thresholdq=1e-1, tissue="placenta", GR){

  DT <- as.data.table(read.table(file, sep=" "))

  setnames(DT, c("NuID","ENTREZID","pvalue","z","sd","effect"))

  DT[,c("significant.p","lower95","upper95","tissue"):=
       list(pvalue<=thresholdp,effect+qnorm(0.025)*sd,effect+qnorm(0.975)*sd,tissue),]

  setkey(DT,NuID)

  # Merge all tables
  DT <- GR[DT]
  set(DT, i=NULL, j="CHR.num", value=sub("chr","", DT[["chr"]]))

  DT[CHR.num=="X",CHR.num:=23]
  DT[CHR.num=="Y",CHR.num:=24]
  DT[,CHR.num:=as.numeric(CHR.num)]

  # significant probes based on pvalue threshold
  #probenames.p <- DT[significant.p==TRUE]

  # q-value
  qobj <- qvalue::qvalue(DT[["pvalue"]])
  set(DT, i=NULL, j="qvalue",value=qobj$qvalues)
  DT[,"significant.q":=qvalue<=thresholdq]

  sigpGranges <- GRanges(seqnames=DT[which(significant.p)][!is.na(chr)]$chr,
                       ranges=IRanges(start=DT[which(significant.p)][!is.na(chr)]$probe.start, end=DT[which(significant.p)][!is.na(chr)]$probe.end,
                                      names=DT[which(significant.p)][!is.na(chr)]$NuID),
                       strand=DT[which(significant.p)][!is.na(chr)]$strand,
                       DT[which(significant.p)][!is.na(chr)][,.(ProbeSequence,ProbeQuality,CodingZone,
                                                                          SymbolReannotated,IlluminaID)],
                       probeStart=DT[which(significant.p)][!is.na(chr)]$probe.start,
                       probeEnd=DT[which(significant.p)][!is.na(chr)]$probe.end)

  sigqGranges <- GRanges(seqnames=DT[which(significant.q)][!is.na(chr)]$chr,
                         ranges=IRanges(start=DT[which(significant.q)][!is.na(chr)]$probe.start, end=DT[which(significant.q)][!is.na(chr)]$probe.end,
                                        names=DT[which(significant.q)][!is.na(chr)]$NuID),
                         strand=DT[which(significant.q)][!is.na(chr)]$strand,
                         DT[which(significant.q)][!is.na(chr)][,.(ProbeSequence,ProbeQuality,CodingZone,
                                                                  SymbolReannotated,IlluminaID)],
                         probeStart=DT[which(significant.q)][!is.na(chr)]$probe.start,
                         probeEnd=DT[which(significant.q)][!is.na(chr)]$probe.end)

  allGranges <- GRanges(seqnames=DT[!is.na(chr)]$chr,
                        ranges=IRanges(start=DT[!is.na(chr)]$probe.start, end=DT[!is.na(chr)]$probe.end,
                                       names=DT[!is.na(chr)]$NuID),
                        strand=DT[!is.na(chr)]$strand,
                        DT[!is.na(chr)][,.(ProbeSequence,ProbeQuality,CodingZone,
                                                                 SymbolReannotated,IlluminaID)],
                        probeStart=DT[!is.na(chr)]$probe.start,
                        probeEnd=DT[!is.na(chr)]$probe.end)


  return(list(results = DT, sigpGranges = sigpGranges, sigqGranges = sigqGranges,
         allGranges = allGranges))

}
